SELECT 'Hello World!' AS greeting;
