SELECT COUNT(DISTINCT language) from hello_worlds;
