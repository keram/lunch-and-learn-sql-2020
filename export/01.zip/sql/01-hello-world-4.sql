SELECT 'Hello' || ' ' || 'World!';
