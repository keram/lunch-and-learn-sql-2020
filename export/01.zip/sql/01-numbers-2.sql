SELECT
5 + 3,
eight * five,
five = eight,
five = 4 + 1,
2 as two
FROM (SELECT 8 AS eight, 5 AS five);
