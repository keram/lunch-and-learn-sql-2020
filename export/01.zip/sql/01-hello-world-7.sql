SELECT COUNT(*) from hello_worlds;
