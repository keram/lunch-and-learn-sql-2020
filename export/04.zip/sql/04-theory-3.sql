INSERT INTO books (author_id, title) VALUES (1, '1984');
