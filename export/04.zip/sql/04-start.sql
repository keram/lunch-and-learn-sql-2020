.open sessions/04/db/week_4.sqlite
