SELECT country, COUNT(*) FROM workers GROUP BY country;
