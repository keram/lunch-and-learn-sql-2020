SELECT * FROM workers WHERE SUBSTR(first_name, 1, 1) = 'O';
