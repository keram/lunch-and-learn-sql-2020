SELECT 'Hello', 'World!';
