SELECT DISTINCT * from hello_worlds;
