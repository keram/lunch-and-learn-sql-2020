SELECT * FROM workers ORDER BY country;
