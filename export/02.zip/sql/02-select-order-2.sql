SELECT * FROM workers ORDER BY shifts_worked DESC;
