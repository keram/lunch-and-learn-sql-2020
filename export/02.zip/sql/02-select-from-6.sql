SELECT * FROM workers;
