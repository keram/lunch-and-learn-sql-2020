SELECT * FROM workers WHERE country = 'AU' OR country = 'NZ';
