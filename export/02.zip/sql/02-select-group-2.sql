SELECT country, SUM(shifts_worked) FROM workers GROUP BY country;
