SELECT * FROM workers WHERE country = 'GB';
