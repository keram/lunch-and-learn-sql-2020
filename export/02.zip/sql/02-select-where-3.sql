SELECT * FROM workers WHERE verified = true AND shifts_worked > 10;
