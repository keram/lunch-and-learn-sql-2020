INSERT INTO hello_worlds
(hello, world, language)
VALUES ('szia', 'világ', 'Hungarian');
