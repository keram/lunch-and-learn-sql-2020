UPDATE hello_worlds
SET world = 'mondo'
WHERE language = 'Italian';
