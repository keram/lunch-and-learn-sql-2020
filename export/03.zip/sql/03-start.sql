.open sessions/03/db/week_3.sqlite
