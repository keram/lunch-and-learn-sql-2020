UPDATE workers
SET verified = false
WHERE postcode = 'SE8 5PA';
