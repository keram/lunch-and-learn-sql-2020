DELETE workers WHERE shifts_worked < 5 OR first_name = 'Oliver';
