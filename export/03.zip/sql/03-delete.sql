DELETE FROM hello_worlds
WHERE language = 'Spanish';
