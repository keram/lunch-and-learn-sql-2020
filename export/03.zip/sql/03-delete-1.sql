DELETE FROM hello_worlds
WHERE language = 'English'
LIMIT 1;
