INSERT INTO workers
(first_name, last_name, telephone, email, country,
postcode, verified, shifts_worked)
VALUES ('James', 'Bond', '007', 'james@mi5.co.uk', 'GB', null, true, null)
